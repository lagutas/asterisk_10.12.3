/*
 * build.h 
 * Automatically generated
 */
#define BUILD_HOSTNAME "pbx01.zadarma.com"
#define BUILD_KERNEL "2.6.32-openvz-042stab083.2-amd64"
#define BUILD_MACHINE "x86_64"
#define BUILD_OS "Linux"
#define BUILD_DATE "2013-11-29 12:52:06 UTC"
#define BUILD_USER "root"

