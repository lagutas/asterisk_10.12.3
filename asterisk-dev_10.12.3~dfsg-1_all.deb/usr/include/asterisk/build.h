/*
 * build.h 
 * Automatically generated
 */
#define BUILD_HOSTNAME "host"
#define BUILD_KERNEL "2.6.32-openvz-042stab081.8-amd64"
#define BUILD_MACHINE "x86_64"
#define BUILD_OS "Linux"
#define BUILD_DATE "2013-11-24 09:39:21 UTC"
#define BUILD_USER "root"

