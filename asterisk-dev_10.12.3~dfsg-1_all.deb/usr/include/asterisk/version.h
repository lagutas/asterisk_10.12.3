/*
 * version.h 
 * Automatically generated
 */
#define ASTERISK_VERSION "10.12.3~dfsg-1"
#define ASTERISK_VERSION_NUM 101203

